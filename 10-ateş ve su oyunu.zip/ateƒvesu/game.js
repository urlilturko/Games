let firePlayer, waterPlayer;
let platforms = [];
let gameWidth = 1600;
let gameHeight = 800;
let socket;
let playerType = null;
let fireExit, waterExit;
let gameWon = false;
let startTime;
let gameStarted = false;
let winner = null;
let timeLimit = 45; // Zor bir süre
let particles = [];
let backgroundImage;

function preload() {
    backgroundImage = loadImage('zindanduvar.jpg');
}

class Particle {
    constructor(x, y, color) {
        this.x = x;
        this.y = y;
        this.color = color;
        this.size = random(2, 5);
        this.speedX = random(-2, 2);
        this.speedY = random(-2, 2);
        this.life = 255;
    }

    update() {
        this.x += this.speedX;
        this.y += this.speedY;
        this.life -= 5;
    }

    draw() {
        noStroke();
        fill(this.color[0], this.color[1], this.color[2], this.life);
        ellipse(this.x, this.y, this.size);
    }
}

class Player {
    constructor(x, y, color, controls) {
        this.x = x;
        this.y = y;
        this.width = 40;
        this.height = 60;
        this.color = color;
        this.velocityY = 0;
        this.jumping = false;
        this.controls = controls;
        this.reachedExit = false;
        this.startX = x;
        this.startY = y;
        this.direction = 1;
        this.gravity = 0.5; // Yerçekimi azaltıldı
        this.jumpForce = -15; // Zıplama kuvveti
    }

    update() {
        // Yerçekimi
        this.velocityY += this.gravity;
        this.y += this.velocityY;

        // Platform kontrolü
        for (let platform of platforms) {
            if (this.y + this.height >= platform.y && 
                this.y + this.height <= platform.y + 10 &&
                this.x + this.width > platform.x && 
                this.x < platform.x + platform.width) {
                this.y = platform.y - this.height;
                this.velocityY = 0;
                this.jumping = false;
            }
        }

        // Zemin kontrolü
        if (this.y + this.height > gameHeight) {
            this.y = gameHeight - this.height;
            this.velocityY = 0;
            this.jumping = false;
        }

        // Çıkış kontrolü
        if (this.color === '#ff4444') {
            if (checkCollision(this, fireExit)) {
                this.reachedExit = true;
                if (!winner) {
                    winner = 'fire';
                    gameWon = true;
                    if (socket) {
                        socket.emit('gameWon', 'fire');
                    }
                }
            }
        } else {
            if (checkCollision(this, waterExit)) {
                this.reachedExit = true;
                if (!winner) {
                    winner = 'water';
                    gameWon = true;
                    if (socket) {
                        socket.emit('gameWon', 'water');
                    }
                }
            }
        }
    }

    reset() {
        this.x = this.startX;
        this.y = this.startY;
        this.velocityY = 0;
        this.jumping = false;
        this.reachedExit = false;
    }

    draw() {
        push();
        if (this.direction === -1) {
            scale(-1, 1);
            translate(-this.x - this.width, this.y);
        } else {
            translate(this.x, this.y);
        }

        noStroke();
        fill(0, 0, 0, 50);
        ellipse(this.width/2, this.height + 5, this.width - 10, 10);

        fill(this.color);
        stroke(0);
        strokeWeight(2);
        rect(0, 0, this.width, this.height, 10);
        
        noStroke();
        if (this.color === '#ff4444') {
            fill(255, 200, 0);
            ellipse(this.width/2, this.height/3, 20, 20);
            fill(255, 100, 0);
            ellipse(this.width/2, this.height/2, 15, 15);
        } else {
            fill(100, 200, 255);
            ellipse(this.width/2, this.height/3, 20, 20);
            fill(0, 100, 255);
            ellipse(this.width/2, this.height/2, 15, 15);
        }
        pop();

        if (this.jumping) {
            for (let i = 0; i < 3; i++) {
                let particleColor = this.color === '#ff4444' ? [255, 100, 0] : [0, 100, 255];
                particles.push(new Particle(
                    this.x + random(this.width),
                    this.y + this.height,
                    particleColor
                ));
            }
        }
    }

    jump() {
        if (!this.jumping) {
            this.velocityY = this.jumpForce;
            this.jumping = true;
        }
    }

    move(direction) {
        const speed = 5;
        if (direction === 'left') {
            this.x -= speed;
            this.direction = -1;
        } else if (direction === 'right') {
            this.x += speed;
            this.direction = 1;
        }

        if (this.color === '#ff4444') {
            if (this.x < 0) this.x = 0;
            if (this.x + this.width > gameWidth/2) this.x = gameWidth/2 - this.width;
        } else {
            if (this.x < gameWidth/2) this.x = gameWidth/2;
            if (this.x + this.width > gameWidth) this.x = gameWidth - this.width;
        }
    }
}

function createPlatforms() {
    platforms = [];
    const platformCount = 20;
    const maxJumpHeight = 150; // Zıplama yüksekliği azaltıldı
    
    // Ateş oyuncusu platformları
    let lastY = gameHeight - 50;
    let lastX = 0;
    
    // Başlangıç platformu
    platforms.push({
        x: 0,
        y: lastY,
        width: 200,
        height: 20
    });
    
    // Ateş oyuncusu için platformlar
    for (let i = 0; i < platformCount; i++) {
        let newY = lastY - random(40, maxJumpHeight);
        let newX = lastX + random(100, 180);
        
        // Ekran sınırlarını kontrol et
        if (newX > gameWidth/2 - 150) {
            newX = gameWidth/2 - 150;
        }
        
        // Yükseklik sınırını kontrol et
        if (newY < 150) {
            newY = 150;
        }
        
        platforms.push({
            x: newX,
            y: newY,
            width: random(80, 140),
            height: 20
        });
        
        lastY = newY;
        lastX = newX;
    }
    
    // Su oyuncusu platformları
    lastY = gameHeight - 50;
    lastX = gameWidth - 200;
    
    // Başlangıç platformu
    platforms.push({
        x: gameWidth - 200,
        y: lastY,
        width: 200,
        height: 20
    });
    
    // Su oyuncusu için platformlar
    for (let i = 0; i < platformCount; i++) {
        let newY = lastY - random(40, maxJumpHeight);
        let newX = lastX - random(100, 180);
        
        // Ekran sınırlarını kontrol et
        if (newX < gameWidth/2 + 50) {
            newX = gameWidth/2 + 50;
        }
        
        // Yükseklik sınırını kontrol et
        if (newY < 150) {
            newY = 150;
        }
        
        platforms.push({
            x: newX,
            y: newY,
            width: random(80, 140),
            height: 20
        });
        
        lastY = newY;
        lastX = newX;
    }
    
    // Çıkış platformları
    platforms.push({
        x: gameWidth/2 - 150,
        y: 100,
        width: 100,
        height: 20
    });
    
    platforms.push({
        x: gameWidth/2 + 50,
        y: 100,
        width: 100,
        height: 20
    });
}

function setup() {
    console.log('setup başladı');
    let canvas = createCanvas(gameWidth, gameHeight);
    canvas.parent('game-canvas');
    console.log('canvas oluşturuldu');
    
    try {
        socket = io('http://localhost:3000');
        console.log('socket bağlantısı kuruldu');
    } catch (error) {
        console.error('Socket bağlantı hatası:', error);
    }

    if (!playerType) {
        playerType = prompt('Oyuncu tipini seçin (fire/water):');
        if (socket) {
            socket.emit('join', playerType);
        }
    }
    
    firePlayer = new Player(50, gameHeight - 100, '#ff4444', {
        up: 87,
        left: 65,
        right: 68
    });
    
    waterPlayer = new Player(gameWidth - 80, gameHeight - 100, '#4444ff', {
        up: UP_ARROW,
        left: LEFT_ARROW,
        right: RIGHT_ARROW
    });

    fireExit = {x: gameWidth/2 - 100, y: 100, width: 50, height: 80};
    waterExit = {x: gameWidth/2 + 50, y: 100, width: 50, height: 80};
    
    createPlatforms();
    startTime = millis();
    gameStarted = true;

    socket.on('players', (players) => {
        for (let id in players) {
            if (id !== socket.id) {
                const otherPlayer = players[id];
                if (otherPlayer.type === 'fire') {
                    firePlayer.x = otherPlayer.x;
                    firePlayer.y = otherPlayer.y;
                } else {
                    waterPlayer.x = otherPlayer.x;
                    waterPlayer.y = otherPlayer.y;
                }
            }
        }
    });

    socket.on('gameWon', (winningPlayer) => {
        winner = winningPlayer;
        gameWon = true;
    });
}

function draw() {
    // Arka plan
    image(backgroundImage, 0, 0, gameWidth, gameHeight);
    
    stroke(255, 255, 255, 100);
    strokeWeight(2);
    line(gameWidth/2, 0, gameWidth/2, gameHeight);
    noStroke();

    for (let platform of platforms) {
        fill(0, 0, 0, 50);
        noStroke();
        rect(platform.x + 5, platform.y + 5, platform.width, platform.height, 5);
        
        fill(139, 69, 19);
        stroke(0);
        strokeWeight(2);
        rect(platform.x, platform.y, platform.width, platform.height, 5);
    }

    fill(255, 0, 0, 200);
    stroke(255, 200, 0);
    strokeWeight(3);
    rect(fireExit.x, fireExit.y, fireExit.width, fireExit.height, 10);
    
    fill(0, 0, 255, 200);
    stroke(100, 200, 255);
    strokeWeight(3);
    rect(waterExit.x, waterExit.y, waterExit.width, waterExit.height, 10);

    if (playerType === 'fire') {
        if (keyIsDown(firePlayer.controls.up)) {
            firePlayer.jump();
        }
        if (keyIsDown(firePlayer.controls.left)) {
            firePlayer.move('left');
        }
        if (keyIsDown(firePlayer.controls.right)) {
            firePlayer.move('right');
        }
        firePlayer.update();
        if (socket) {
            socket.emit('updatePosition', {
                x: firePlayer.x,
                y: firePlayer.y
            });
        }
    } else {
        if (keyIsDown(waterPlayer.controls.up)) {
            waterPlayer.jump();
        }
        if (keyIsDown(waterPlayer.controls.left)) {
            waterPlayer.move('left');
        }
        if (keyIsDown(waterPlayer.controls.right)) {
            waterPlayer.move('right');
        }
        waterPlayer.update();
        if (socket) {
            socket.emit('updatePosition', {
                x: waterPlayer.x,
                y: waterPlayer.y
            });
        }
    }

    firePlayer.draw();
    waterPlayer.draw();

    for (let i = particles.length - 1; i >= 0; i--) {
        particles[i].update();
        particles[i].draw();
        if (particles[i].life <= 0) {
            particles.splice(i, 1);
        }
    }

    if (checkCollision(firePlayer, waterPlayer)) {
        firePlayer.reset();
        waterPlayer.reset();
        
        for (let i = 0; i < 20; i++) {
            particles.push(new Particle(
                (firePlayer.x + waterPlayer.x) / 2,
                (firePlayer.y + waterPlayer.y) / 2,
                [255, 255, 255]
            ));
        }
    }

    if (gameStarted && !gameWon) {
        let currentTime = millis();
        let elapsedTime = (currentTime - startTime) / 1000;
        let remainingTime = Math.max(0, timeLimit - elapsedTime);
        
        fill(0, 0, 0, 150);
        noStroke();
        rect(gameWidth/2 - 100, 10, 200, 40, 10);
        
        fill(255);
        textSize(24);
        textAlign(CENTER);
        text(remainingTime.toFixed(1), gameWidth/2, 35);

        if (remainingTime <= 0) {
            gameWon = true;
            winner = 'timeout';
            if (socket) {
                socket.emit('gameWon', 'timeout');
            }
        }
    }

    if (gameWon) {
        fill(0, 0, 0, 150);
        rect(0, 0, gameWidth, gameHeight);
        
        fill(255);
        textSize(48);
        textAlign(CENTER, CENTER);
        let message;
        if (winner === 'fire') {
            message = 'Ateş Oyuncusu Kazandı!';
        } else if (winner === 'water') {
            message = 'Su Oyuncusu Kazandı!';
        } else if (winner === 'timeout') {
            message = 'Süre Doldu! Kimse Kazanamadı!';
        }
        text(message, gameWidth/2, gameHeight/2);
        textAlign(LEFT, TOP);
    }

    fill(255);
    textSize(16);
    textAlign(LEFT);
    text('FPS: ' + Math.round(frameRate()), 10, 20);
    text('Oyuncu: ' + playerType, 10, 40);
}

function checkCollision(obj1, obj2) {
    return obj1.x < obj2.x + obj2.width &&
           obj1.x + obj1.width > obj2.x &&
           obj1.y < obj2.y + obj2.height &&
           obj1.y + obj1.height > obj2.y;
} 