const express = require('express');
const app = express();
const http = require('http').createServer(app);
const io = require('socket.io')(http, {
    cors: {
        origin: "*",
        methods: ["GET", "POST"]
    }
});

// Statik dosyaları sun
app.use(express.static('./'));

// Ana sayfa
app.get('/', (req, res) => {
    res.sendFile(__dirname + '/index.html');
});

const players = {};

io.on('connection', (socket) => {
    console.log('Bir oyuncu bağlandı');

    socket.on('join', (playerType) => {
        players[socket.id] = {
            type: playerType,
            x: playerType === 'fire' ? 100 : 700,
            y: 300
        };
        io.emit('players', players);
    });

    socket.on('updatePosition', (data) => {
        if (players[socket.id]) {
            players[socket.id].x = data.x;
            players[socket.id].y = data.y;
            io.emit('players', players);
        }
    });

    socket.on('disconnect', () => {
        delete players[socket.id];
        io.emit('players', players);
        console.log('Bir oyuncu ayrıldı');
    });
});

const PORT = process.env.PORT || 3000;
http.listen(PORT, () => {
    console.log(`Sunucu ${PORT} portunda çalışıyor`);
}); 